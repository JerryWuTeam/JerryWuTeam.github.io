#include "simple.h"

float val_to_pct(int val, int min, int max)
{
    int length = abs(max - min);
    int pval = val - min;
    float pct = abs(1.0 * pval / length);
    return pct;
}

int pct_to_val(float pct, int min, int max)
{
    int length = abs(max - min);
    int pval = abs(length * pct);
    int val = pval + min;
    return val;
}

void explain(char txt[], float num)
{
    s.print(txt);
    s.println(num);
}

void pwm(int pin, long int time, int period, float dutycycle)
{
    int times = time / period;
    float dutytime = period * dutycycle;
    for (int i = 0; i <= times; i++)
    {
        dwrite(pin, high);
        delay(dutytime);
        dwrite(pin, low);
        delay(period - dutytime);
    }
}

void pwm_once(int pin, int period, float dutycycle)
{
    float dutytime = period * dutycycle;
    dwrite(pin, high);
    delay(dutytime);
    dwrite(pin, low);
    delay(period - dutytime);
}