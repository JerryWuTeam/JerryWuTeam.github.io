#include <Arduino.h>
#include <math.h>

#define setmode(pin, mode) pinMode(pin, mode)
#define dwrite(pin, val) digitalWrite(pin, val)
#define dread(pin) digitalRead(pin)
#define settype(type) analogReference(type)
#define awrite(pin, val) analogWrite(pin, val)
#define aread(pin) analogRead(pin)
#define s Serial
#define output OUTPUT
#define input INPUT
#define high HIGH
#define low LOW
#define input_pullup INPUT_PULLUP
#define default DEFAULT
#define intl INTERNAL
#define ext EXTERNAL

float val_to_pct(int val, int min, int max);
int pct_to_val(float pct, int min, int max);
void explain(char txt[], float num);
void pwm(int pin, long int time, int period, float dutycycle);
void pwm_once(int pin, int period, float dutycycle);
